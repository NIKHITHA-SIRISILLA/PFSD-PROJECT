from flask import Flask, render_template, request, send_file
import pytesseract
from PIL import Image
from io import BytesIO

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    if 'imageFile' not in request.files:
        return "No file part"

    file = request.files['imageFile']

    if file.filename == '':
        return "No image selected"

    # Read image file
    img = Image.open(BytesIO(file.read()))

    # Use pytesseract to extract text
    extracted_text = pytesseract.image_to_string(img)

    return render_template('result.html', text=extracted_text)


@app.route('/download')
def download():
    text = request.args.get('text', '')
    if text:
        # Create a temporary file to store text
        temp_file = BytesIO()
        temp_file.write(text.encode('utf-8'))
        temp_file.seek(0)

        return send_file(temp_file, as_attachment=True, download_name='extracted_text.txt')

    return "No text to download"


if __name__ == '__main__':
    app.run(debug=True)
