r = int(input("Enter the number of rows:"))
c = int(input("Enter the number of columns:"))
matrix = []
print("Enter the elements of matrix:")
# For user input
for i in range(r):
    k = []
    for j in range(c):
        k.append(int(input()))
        matrix.append(k)
# For printing the matrix
for i in range(r):
    for j in range(c):
        print(matrix[i][j], end=" ")
    print()