
from PIL import Image
import pytesseract
if __name__ == '__main__':
    print(pytesseract.image_to_string(Image.open(r"C:\Users\Nikhitha Reddy\OneDrive\Desktop\vivi.jpg")))
    # print(pytesseract.image_to_string(Image.open(r'test-european.jpg'), lang='fra'))
    print(pytesseract.image_to_string(r"C:\Users\Nikhitha Reddy\OneDrive\Desktop\abdul.png"))

